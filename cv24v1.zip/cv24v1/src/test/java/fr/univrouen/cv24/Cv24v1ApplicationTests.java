package fr.univrouen.cv24;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Cv24v1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
